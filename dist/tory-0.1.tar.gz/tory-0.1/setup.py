from setuptools import setup

setup(name='tory',
      version='0.1',
      description='inventory program',
      url='http://github.com/tbenz9/tory',
      author='Team Awesome',
      author_email='tbenz9@llnl.gov',
      license='LLNL',
      packages=['tory'],
      zip_safe=False)
